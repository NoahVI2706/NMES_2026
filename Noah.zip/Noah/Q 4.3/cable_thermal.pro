DefineConstant[
  bottom_bc = {1, Choices {0="Dirichlet T=T_amb",1="Zero flux"}, Name "Boundary/Bottom condition"},
  kappa_uniform = {0, Choices {0="Real kappa",1="Uniform kappa=1"}, Name "Test/Uniform kappa"},
  outer_all_dirichlet = {0, Choices {0="Normal boundaries",1="All outer boundaries Dirichlet"}, Name "Test/All outer boundaries Dirichlet"},
  T_amb = {20.0, Name "Thermal/Ambient temperature [C]"},
  h = {500.0, Name "Thermal/Convection coefficient [W/m2/K]"},
  P_cond_per_core = {16.3372037279, Name "Thermal/Conductor source [W/m]"},
  P_sheath_per_core = {0.4513616206, Name "Thermal/Lead sheath source [W/m]"},
  P_armour_total = {2.9270646187, Name "Thermal/Armour source [W/m]"},
  P_seabed_total = {1.5339867e-7, Name "Thermal/Seabed source [W/m]"},
  kappa_seabed = {1.0, Name "Thermal/kappa seabed [W/m/K]"}, // Assumed
  kappa_xlpe = {0.46, Name "Thermal/kappa XLPE [W/m/K]"},
  kappa_lead = {35.0, Name "Thermal/kappa lead [W/m/K]"},
  kappa_aluminium = {237.0, Name "Thermal/kappa aluminium [W/m/K]"},
  kappa_steel = {50.2, Name "Thermal/kappa steel [W/m/K]"}, // Assumed
  kappa_polyethylene = {0.46, Name "Thermal/kappa polyethylene [W/m/K]"}, // Assumed
  kappa_filler = {0.4, Name "Thermal/kappa filler [W/m/K]"}, // Assumed
  kappa_semiconductor = {10.0, Name "Thermal/kappa semiconductor [W/m/K]"}, // Assumed
  r_conductor = {0.00905, Name "Geometry/Conductor radius [m]"},
  r_outerScreen = {0.01875, Name "Geometry/Outer screen radius [m]"},
  r_lead = {0.02025, Name "Geometry/Lead radius [m]"}, // 40.5 mm existing diameter
  // TODO: Replace with the datasheet lead outer radius if it differs from 40.5 mm.
  L = {1.0, Name "Geometry/Translation depth L [m]"},
  x_A = {0.0, Name "Geometry/Core A x [m]"},
  x_B = {-0.022, Name "Geometry/Core B x [m]"},
  x_C = {0.022, Name "Geometry/Core C x [m]"},
  y_A0 = {0.0254, Name "Geometry/Core A original y [m]"},
  y_B0 = {-0.0127, Name "Geometry/Core B original y [m]"},
  y_C0 = {-0.0127, Name "Geometry/Core C original y [m]"}
];

Include "thermal_formulation.pro";
